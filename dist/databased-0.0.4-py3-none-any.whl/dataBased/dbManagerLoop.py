import os

while True:
    args = input("Enter command: ")
    os.system(f"dbManager.py {args}")
